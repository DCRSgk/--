// code by DCRSgk
// file: homework02.cpp
// since: 2020-05-29
// desc: simple stack-> push/pop/full/empty

#include <iostream>
using std::cout;
using std::cin;
using std::endl;
class Stack
{
public:
    Stack()
    {
        _topStack = -1;
        _maxSize = 10;
    }
    ~Stack(){}
    void stackPush(int val)
    {
        if(stackIsFull())
        {
            cout << "error stack overflow!"
                 << endl; 
            exit(0);
        }
        _maxSize--;
        _stackData[++_topStack] = val;
    }
    void stackPop()
    {
        if(stackIsEmpty())
        {
            exit(1);
        }
        _topStack--;
    }
    int stackTop()
    {
        return _stackData[_topStack];
    }
    bool stackIsFull()
    {
        return 9 == _topStack;
    }
    bool stackIsEmpty()
    {
        return -1 == _topStack;
    }
private:
    int _topStack;
    int _maxSize;
    int _stackData[10];
};

