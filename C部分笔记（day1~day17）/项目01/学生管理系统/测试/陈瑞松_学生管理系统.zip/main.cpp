#include"myLibrary.h"
int main()
{
	
	loadUser();
	loadStudent();
	//printAccount();
	//systemMenu1();
	//systemMenu2();
	loginMenu();
	//addStudentInfo();
	//printStudentInfo();
	//systemMenu2();
	//studentSearch();



error:
	system("pause");
}
