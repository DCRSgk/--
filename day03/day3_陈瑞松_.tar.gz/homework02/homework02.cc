// Code by DCRSgk
// file: homework02.cc
// since: 2020-05-29
// dcsc: simple stack main


#include "homework02.hpp"
int main()
{
    Stack S;
    S.stackPush(11);
    cout << "stack top is " 
         << S.stackTop()<<endl;
    S.stackPush(43);    
    cout << "stack top is " 
         << S.stackTop()<<endl;
    S.stackPush(69);    
    cout << "stack top is " 
         << S.stackTop()<<endl;
    S.stackPush(77);    
    cout << "stack top is " 
         << S.stackTop()<<endl;
    /* push to stack */
    
    S.stackPop();
    cout << "stack top is " 
         << S.stackTop()<<endl;
    /* pop to stack */
    
    for (int i = 0; i < 9; i++)
    {
        S.stackPush(i);
    }
    /* test: if stack full */
     
    for (int i = 0; i < 10; i++)
    {
        S.stackPop();
    }
    return 0;
}

