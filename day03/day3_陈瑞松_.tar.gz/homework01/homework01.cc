#include <iostream>
using std::cout;
using std::endl;
class rectangle
{
public:
    rectangle(int x,int y)
    :_x(x)
    ,_y(y)
    {

    }
    
    inline
    int Perimeter()
    {
       return  2 * ( _x + _y );
    }
    int Area()
    {
        return _x * _y;
    }
private:
    int _x;
    int _y;



};
int main()
{
    rectangle a1(4,3);
    rectangle a2(6,9);
    cout<<"The perimeter of rectangle a1 is " 
        << a1.Perimeter() 
        << " and the area is "
        << a1.Area()
        <<endl;
    cout<<"The perimeter of rectangle a2 is " 
        << a2.Perimeter() 
        << " and the area is "
        << a2.Area()
        <<endl;

    
    
    
    
    return 0;
}

